from core.application import VantaApplication
if __name__ == "__main__": VantaApplication().start()
