import tkinter as tk
from tkinter import ttk,messagebox,simpledialog
from core.config import VERSION
def about(p):
 w=tk.Toplevel(p);w.title('About VANTA');w.geometry('400x300');w.configure(bg='#050505');tk.Label(w,text='▼',bg='#050505',fg='white',font=('Segoe UI',70,'bold')).pack();tk.Label(w,text='VANTA IDE',bg='#050505',fg='white',font=('Segoe UI',20,'bold')).pack();tk.Label(w,text='Version '+VERSION,bg='#050505',fg='#999').pack(pady=6);tk.Label(w,text='Python standard-library-first development environment',bg='#050505',fg='#ccc').pack(pady=20);ttk.Button(w,text='Close',command=w.destroy).pack()
def error(p,msg):messagebox.showerror('VANTA',msg,parent=p)
def askline(p):return simpledialog.askinteger('Go to Line','Line:',parent=p,minvalue=1)
