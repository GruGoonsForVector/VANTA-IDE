import tkinter as tk

def menu(a):
    base = {'tearoff': False, 'bg': '#0D1016', 'fg': '#F2F5F9', 'activebackground': '#29233E', 'activeforeground': 'white'}
    m = tk.Menu(a.root, **base)
    f = tk.Menu(m, **base)
    for n, c in [('New File', a.new), ('Open File', a.openfile), ('Open Folder', a.openfolder),
                 ('Save', a.save), ('Save As', a.saveas), ('Save All', a.saveall), ('Close Tab', a.close)]:
        f.add_command(label=n, command=c)
    f.add_separator(); f.add_command(label='Exit', command=a.closeapp)
    m.add_cascade(label='File', menu=f)

    e = tk.Menu(m, **base)
    for n, c in [('Undo', lambda: a.ed.t.event_generate('<<Undo>>')),
                 ('Redo', lambda: a.ed.t.event_generate('<<Redo>>')),
                 ('Find', a.find), ('Replace', a.replace), ('Go to Line', a.goto)]:
        e.add_command(label=n, command=c)
    m.add_cascade(label='Edit', menu=e)

    v = tk.Menu(m, **base)
    for n, c in [('Command Palette', a.palette), ('Toggle Explorer', a.toggle_explorer),
                 ('Toggle Terminal', a.toggle_terminal), ('Fullscreen', a.toggle_fullscreen),
                 ('Word Wrap', a.ed.wrap), ('Font +', lambda: a.ed.fontchange(1)),
                 ('Font -', lambda: a.ed.fontchange(-1))]:
        v.add_command(label=n, command=c)
    m.add_cascade(label='View', menu=v)

    r = tk.Menu(m, **base)
    r.add_command(label='Run Current File', command=a.run)
    r.add_command(label='Run Selection', command=a.run_selection)
    r.add_command(label='Stop', command=a.stop)
    m.add_cascade(label='Run', menu=r)

    t = tk.Menu(m, **base)
    t.add_command(label='Python Packages / Extensions', command=a.packages)
    t.add_command(label='Open Terminal', command=a.toggle_terminal)
    m.add_cascade(label='Tools', menu=t)

    h = tk.Menu(m, **base)
    h.add_command(label='About VANTA', command=a.about)
    m.add_cascade(label='Help', menu=h)
    return m
