import tkinter as tk
class Palette(tk.Toplevel):
 def __init__(self,p,cmds):
  super().__init__(p);self.cmds=cmds;self.title('Command Palette');self.geometry('650x430');self.configure(bg='#0A0A0A');self.e=tk.Entry(self,bg='#101010',fg='white',insertbackground='white',font=('Consolas',12),relief='flat');self.e.pack(fill='x',padx=12,pady=12,ipady=7);self.l=tk.Listbox(self,bg='#0A0A0A',fg='white',selectbackground='#292929',relief='flat');self.l.pack(fill='both',expand=True,padx=12,pady=(0,12));self.e.bind('<KeyRelease>',self.refresh);self.e.bind('<Return>',self.run);self.refresh();self.e.focus()
 def refresh(self,e=None):
  q=self.e.get().lower();self.l.delete(0,'end');self.matches=[x for x in self.cmds if q in x[0].lower()];[self.l.insert('end',x[0]) for x in self.matches]
 def run(self,e=None):
  if self.matches:self.destroy();self.matches[self.l.curselection()[0] if self.l.curselection() else 0][1]()
