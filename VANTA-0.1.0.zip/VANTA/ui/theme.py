from tkinter import ttk

VANTA = {
    'bg': '#07080C',
    'panel': '#0D1016',
    'panel2': '#121722',
    'panel3': '#181E2A',
    'border': '#252C3A',
    'text': '#F2F5F9',
    'muted': '#7E8798',
    'accent': '#8B5CF6',
    'accent2': '#5EEAD4',
    'select': '#29233E',
    'editor': '#0B0D12',
    'error': '#FF6B7A',
    'success': '#5EE7A4',
}

def configure(root):
    s = ttk.Style(root)
    s.theme_use('clam')
    s.configure('.', background=VANTA['panel'], foreground=VANTA['text'], font=('Segoe UI', 9))
    s.configure('TFrame', background=VANTA['panel'])
    s.configure('TLabel', background=VANTA['panel'], foreground=VANTA['text'])
    s.configure('Muted.TLabel', background=VANTA['panel'], foreground=VANTA['muted'])
    s.configure('Title.TLabel', background=VANTA['panel'], foreground=VANTA['text'], font=('Segoe UI Semibold', 10))
    s.configure('TButton', background=VANTA['panel2'], foreground=VANTA['text'], padding=(10, 6), borderwidth=0, relief='flat')
    s.map('TButton', background=[('active', VANTA['panel3']), ('pressed', VANTA['select'])])
    s.configure('Accent.TButton', background=VANTA['accent'], foreground='white', padding=(12, 6))
    s.map('Accent.TButton', background=[('active', '#9B73F8'), ('pressed', '#7544E5')])
    s.configure('TEntry', fieldbackground=VANTA['panel2'], foreground=VANTA['text'], insertcolor='white', borderwidth=0, padding=6)
    s.configure('Treeview', background=VANTA['panel'], fieldbackground=VANTA['panel'], foreground=VANTA['text'], rowheight=27, borderwidth=0, font=('Segoe UI', 9))
    s.map('Treeview', background=[('selected', VANTA['select'])], foreground=[('selected', 'white')])
    s.configure('TPanedwindow', background=VANTA['border'])
    s.configure('TNotebook', background=VANTA['panel'], borderwidth=0)
    s.configure('TScrollbar', background=VANTA['panel2'], troughcolor=VANTA['editor'], borderwidth=0, arrowsize=10)
    s.map('TScrollbar', background=[('active', VANTA['panel3'])])
