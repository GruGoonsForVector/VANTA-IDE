import re
def find_matches(text,q,case=False,whole=False,regex=False):
 if not q:return []
 pat=q if regex else re.escape(q); pat=(r'\b'+pat+r'\b') if whole else pat
 try:return list(re.finditer(pat,text,0 if case else re.I))
 except re.error:return []
