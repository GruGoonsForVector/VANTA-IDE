import tkinter as tk
import re
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from editor.syntax import highlight

class Editor(ttk.Frame):
    def __init__(self, master, cfg, changed):
        super().__init__(master)
        self.cfg = cfg
        self.changed = changed
        self.docs = []
        self.cur = None
        self.font = cfg.get('font_size', 11)
        self.tab_size = int(cfg.get('tab_size', 4))

        self.bar = tk.Frame(self, bg='#0D1016', highlightthickness=1, highlightbackground='#252C3A')
        self.bar.pack(fill='x')
        self.tabs = tk.Frame(self.bar, bg='#0D1016')
        self.tabs.pack(side='left', fill='x', expand=True)
        tk.Button(self.bar, text='+', width=3, command=self.new, relief='flat', bd=0, bg='#121722', fg='#DCE3ED', activebackground='#29233E', activeforeground='white', font=('Segoe UI Semibold', 10), cursor='hand2').pack(side='right', padx=5, pady=5)

        body = ttk.Frame(self)
        body.pack(fill='both', expand=True)
        self.n = tk.Text(body, width=5, bg='#11131A', fg='#5F6675', state='disabled',
                         font=('Consolas', self.font), relief='flat', padx=8, pady=8,
                         takefocus=False)
        self.n.pack(side='left', fill='y')

        self.t = tk.Text(body, bg='#0B0D12', fg='#E8ECF1', insertbackground='#FFFFFF',
                         selectbackground='#343B4A', selectforeground='#FFFFFF',
                         font=('Consolas', self.font), undo=True, wrap='none', relief='flat',
                         padx=12, pady=8, spacing1=1, spacing3=1)
        self.t.pack(side='left', fill='both', expand=True)
        self.vscroll = ttk.Scrollbar(body, command=self._yscroll)
        self.vscroll.pack(side='right', fill='y')
        self.hscroll = ttk.Scrollbar(self, orient='horizontal', command=self.t.xview)
        self.hscroll.pack(fill='x')
        self.t.configure(yscrollcommand=self.sync, xscrollcommand=self.hscroll.set)

        self.t.tag_configure('currentline', background='#10141D')
        for k, c in [('kw','#C9B8FF'),('str','#A9E8C3'),('comment','#667085'),
                     ('number','#DDB7FF'),('builtin','#8FD7FF'),('operator','#C2C8D0')]:
            self.t.tag_configure(k, foreground=c)
        self.t.tag_configure('match', background='#4A405B')
        self.t.tag_configure('diag', foreground='#FF7474', underline=True)

        self.t.bind('<<Modified>>', self.mod)
        self.t.bind('<Return>', self.indent)
        self.t.bind('<KP_Enter>', self.indent)
        self.t.bind('<Tab>', self.tab)
        self.t.bind('<Shift-Tab>', self.unindent)
        self.t.bind('<KeyRelease>', self.keyrelease)
        self.t.bind('<ButtonRelease-1>', lambda e: self.refresh())
        self.t.bind('<Control-plus>', lambda e: self.fontchange(1))
        self.t.bind('<Control-equal>', lambda e: self.fontchange(1))
        self.t.bind('<Control-minus>', lambda e: self.fontchange(-1))
        self.new()

    def _yscroll(self, *args):
        self.t.yview(*args)
        self.n.yview(*args)

    def sync(self, first, last):
        self.vscroll.set(first, last)
        self.n.yview_moveto(first)

    def keyrelease(self, _event=None):
        self.refresh()

    def refresh(self):
        try:
            highlight(self.t)
        except Exception:
            pass
        self.t.tag_remove('currentline', '1.0', 'end')
        line = self.t.index('insert').split('.')[0]
        self.t.tag_add('currentline', f'{line}.0', f'{line}.end+1c')
        last = max(1, int(self.t.index('end-1c').split('.')[0]))
        self.n.config(state='normal')
        self.n.delete('1.0', 'end')
        self.n.insert('1.0', '\n'.join(map(str, range(1, last + 1))))
        self.n.config(state='disabled')
        self.changed()

    def mod(self, _event=None):
        if self.t.edit_modified():
            if self.cur is not None:
                self.docs[self.cur]['dirty'] = True
            self.t.edit_modified(False)
            self.refresh()
            self.drawtabs()

    def drawtabs(self):
        for x in self.tabs.winfo_children():
            x.destroy()
        for i, d in enumerate(self.docs):
            name = d['path'].name if d['path'] else d.get('name', 'Untitled.py')
            active = i == self.cur
            tab = tk.Frame(self.tabs, bg='#181E2A' if active else '#0D1016',
                           highlightthickness=1,
                           highlightbackground='#3A4252' if active else '#252C3A')
            tab.pack(side='left', padx=(2, 0), pady=3)
            label = ('* ' if d['dirty'] else '') + name
            tk.Button(tab, text=label, command=lambda i=i: self.select(i), relief='flat', bd=0,
                      bg='#181E2A' if active else '#0D1016', fg='#FFFFFF' if active else '#8E98AA',
                      activebackground='#29233E', activeforeground='#FFFFFF', padx=10, pady=5,
                      font=('Segoe UI', 9), cursor='hand2').pack(side='left')
            tk.Button(tab, text='X', command=lambda i=i: self.close(i), relief='flat', bd=0,
                      bg='#181E2A' if active else '#0D1016', fg='#8E98AA',
                      activebackground='#3A2530', activeforeground='#FFFFFF', padx=6, pady=5,
                      font=('Segoe UI Semibold', 8), cursor='hand2').pack(side='left')

    def new(self, text='', path=None):
        self.docs.append({'path': Path(path) if path else None, 'text': text, 'dirty': False, 'name': Path(path).name if path else 'Untitled.py'})
        self.select(len(self.docs) - 1)

    def select(self, i):
        if self.cur is not None:
            self.docs[self.cur]['text'] = self.t.get('1.0', 'end-1c')
        self.cur = i
        d = self.docs[i]
        self.t.delete('1.0', 'end')
        self.t.insert('1.0', d['text'])
        self.t.edit_modified(False)
        self.drawtabs()
        self.refresh()
        self.t.focus_set()

    def open(self, p):
        p = Path(p)
        for i, d in enumerate(self.docs):
            if d['path'] and d['path'].resolve() == p.resolve():
                self.select(i)
                return
        try:
            text = p.read_text(encoding='utf-8')
            self.new(text, p)
        except UnicodeDecodeError:
            messagebox.showerror('VANTA', 'This file is not a UTF-8 text file.')
        except OSError as e:
            messagebox.showerror('VANTA', str(e))

    def save(self, saveas=False):
        if self.cur is None:
            return False
        d = self.docs[self.cur]
        p = d['path']
        if saveas or not p:
            q = filedialog.asksaveasfilename(parent=self, title='Save File', initialfile=d.get('name', 'Untitled.py'), defaultextension='.py', filetypes=[('Python files', '*.py'), ('Text files', '*.txt'), ('All files', '*.*')])
            if not q:
                return False
            p = d['path'] = Path(q)
            d['name'] = p.name
        d['text'] = self.t.get('1.0', 'end-1c')
        try:
            p.write_text(d['text'], encoding='utf-8')
            d['dirty'] = False
            self.drawtabs()
            return True
        except Exception as e:
            messagebox.showerror('Save Error', str(e), parent=self)
            return False

    def close(self, index=None):
        if not self.docs:
            return True
        if index is None:
            index = self.cur
        if index is None or index < 0 or index >= len(self.docs):
            return True
        d = self.docs[index]
        if d['dirty']:
            old = self.cur
            self.select(index)
            r = messagebox.askyesnocancel('Unsaved Changes',
                                          f'Save changes to {d.get("name", "Untitled.py")} before closing?',
                                          parent=self)
            if r is None:
                if old is not None and old < len(self.docs): self.select(old)
                return False
            if r and not self.save():
                return False
        self.docs.pop(index)
        if self.docs:
            self.cur = min(index, len(self.docs) - 1)
            self.select(self.cur)
        else:
            self.cur = None
            self.new()
        return True

    def indent(self, _event=None):
        line = self.t.get('insert linestart', 'insert')
        base = re.match(r'[ \t]*', line).group(0)
        extra = ' ' * self.tab_size if line.rstrip().endswith(':') else ''
        self.t.insert('insert', '\n' + base + extra)
        return 'break'

    def tab(self, _event=None):
        self.t.insert('insert', ' ' * self.tab_size)
        return 'break'

    def unindent(self, _event=None):
        a = self.t.index('insert linestart')
        s = self.t.get(a, 'insert')
        n = min(len(s) - len(s.lstrip(' ')), self.tab_size)
        if n:
            self.t.delete(a, f'{a}+{n}c')
        return 'break'

    def wrap(self):
        self.t.configure(wrap='word' if self.t.cget('wrap') == 'none' else 'none')
        self.cfg.set('word_wrap', self.t.cget('wrap') != 'none')

    def fontchange(self, d):
        self.font = max(8, min(32, self.font + d))
        self.t.configure(font=('Consolas', self.font))
        self.n.configure(font=('Consolas', self.font))
        self.cfg.set('font_size', self.font)
