import io,tokenize,keyword
def highlight(w):
 for x in ['kw','str','comment','number','builtin','operator']:w.tag_remove(x,'1.0','end')
 try:
  for t in tokenize.generate_tokens(io.StringIO(w.get('1.0','end-1c')).readline):
   a=f'{t.start[0]}.{t.start[1]}';b=f'{t.end[0]}.{t.end[1]}'
   if t.type==tokenize.NAME and t.string in keyword.kwlist:w.tag_add('kw',a,b)
   elif t.type==tokenize.STRING:w.tag_add('str',a,b)
   elif t.type==tokenize.COMMENT:w.tag_add('comment',a,b)
   elif t.type==tokenize.NUMBER:w.tag_add('number',a,b)
   elif t.type==tokenize.OP:w.tag_add('operator',a,b)
 except (tokenize.TokenError,IndentationError):pass
