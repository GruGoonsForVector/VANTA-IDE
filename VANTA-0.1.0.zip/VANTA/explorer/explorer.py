import tkinter as tk,shutil
from tkinter import ttk,simpledialog,messagebox
from pathlib import Path
class Explorer(ttk.Frame):
 def __init__(self,m,openf,getroot):
  super().__init__(m);self.openf=openf;self.getroot=getroot;h=ttk.Frame(self);h.pack(fill='x');ttk.Label(h,text='FILES',font=('Segoe UI',8,'bold')).pack(side='left',padx=8,pady=6);ttk.Button(h,text='REFRESH',width=9,command=self.refresh).pack(side='right',padx=2);ttk.Button(h,text='NEW',width=6,command=self.new).pack(side='right',padx=2);self.tree=ttk.Treeview(self,show='tree');self.tree.pack(fill='both',expand=True);self.tree.bind('<Double-1>',self.open);self.tree.bind('<Button-3>',self.menu);self.refresh()
 def refresh(self):
  self.tree.delete(*self.tree.get_children());r=self.getroot()
  if r:self.fill(self.tree.insert('','end',text=r.name,values=[str(r)],open=True),r)
 def fill(self,i,p):
  try:xs=sorted(p.iterdir(),key=lambda x:(not x.is_dir(),x.name.lower()))
  except:return
  for x in xs:
   if x.name in ['.git','__pycache__','.vanta']:continue
   q=self.tree.insert(i,'end',text=('[DIR] ' if x.is_dir() else '      ')+x.name,values=[str(x)])
   if x.is_dir():self.tree.insert(q,'end',text='...')
 def open(self,e=None):
  i=self.tree.focus();
  if not i:return
  p=Path(self.tree.item(i,'values')[0]);self.openf(p) if p.is_file() else None
 def menu(self,e):
  i=self.tree.identify_row(e.y);
  if not i:return
  p=Path(self.tree.item(i,'values')[0]);m=tk.Menu(self,tearoff=False);m.add_command(label='New File',command=lambda:self.create(p,False));m.add_command(label='New Folder',command=lambda:self.create(p,True));m.add_command(label='Rename',command=lambda:self.rename(p));m.add_command(label='Delete',command=lambda:self.delete(p));m.add_command(label='Refresh',command=self.refresh);m.tk_popup(e.x_root,e.y_root)
 def new(self):
  r=self.getroot()
  if r:self.create(r,False)
 def create(self,p,d):
  n=simpledialog.askstring('VANTA','Name:');
  if n:
   try:(p/n).mkdir() if d else (p/n).touch();self.refresh()
   except Exception as e:messagebox.showerror('Filesystem',str(e))
 def rename(self,p):
  n=simpledialog.askstring('Rename','New name:',initialvalue=p.name);
  if n:
   try:p.rename(p.parent/n);self.refresh()
   except Exception as e:messagebox.showerror('Filesystem',str(e))
 def delete(self,p):
  if messagebox.askyesno('Delete',f'Delete {p.name}?'):
   try:shutil.rmtree(p) if p.is_dir() else p.unlink();self.refresh()
   except Exception as e:messagebox.showerror('Filesystem',str(e))
