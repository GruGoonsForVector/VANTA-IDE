import json, os
from pathlib import Path
VERSION="0.1.0-dev"; APP_NAME="VANTA IDE"
CONFIG_DIR=Path(os.getenv("APPDATA",Path.home()))/"VANTA"; CONFIG_FILE=CONFIG_DIR/"settings.json"; STATE_FILE=CONFIG_DIR/"state.json"; LOG_DIR=CONFIG_DIR/"logs"
DEFAULTS={"theme":"vanta-dark","font_family":"Consolas","font_size":11,"tab_size":4,"insert_spaces":True,"word_wrap":False,"line_numbers":True,"autosave":False,"terminal_shell":"auto","restore_workspace":True}
class Config:
 def __init__(self): self.data=dict(DEFAULTS); self.load()
 def load(self):
  try:
   if CONFIG_FILE.exists(): self.data.update(json.loads(CONFIG_FILE.read_text(encoding="utf8")))
  except Exception: pass
 def save(self): CONFIG_DIR.mkdir(parents=True,exist_ok=True); CONFIG_FILE.write_text(json.dumps(self.data,indent=2),encoding="utf8")
 def get(self,k,d=None): return self.data.get(k,d)
 def set(self,k,v): self.data[k]=v; self.save()
def state():
 try: return json.loads(STATE_FILE.read_text(encoding="utf8")) if STATE_FILE.exists() else {}
 except Exception:return {}
def save_state(x): CONFIG_DIR.mkdir(parents=True,exist_ok=True); STATE_FILE.write_text(json.dumps(x,indent=2),encoding="utf8")
