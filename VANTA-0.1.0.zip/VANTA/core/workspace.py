from pathlib import Path
from core.config import state,save_state
class Workspace:
 def __init__(self): self.root=None; self.recent=state().get("recent_projects",[])
 def set_root(self,p):
  p=Path(p).resolve(); assert p.is_dir(); self.root=p; s=str(p); self.recent=[x for x in self.recent if x!=s][:9]; self.recent.insert(0,s); save_state({"recent_projects":self.recent,"workspace":s})
 def project_file(self): return self.root/".vanta"/"project.json" if self.root else None
 def save_settings(self,d):
  if self.root: self.project_file().parent.mkdir(exist_ok=True); self.project_file().write_text(__import__('json').dumps(d,indent=2),encoding='utf8')
 @staticmethod
 def detect_root(p):
  p=Path(p).resolve(); p=p if p.is_dir() else p.parent
  for x in [p,*p.parents]:
   if (x/'.git').exists() or (x/'.vanta').exists(): return x
  return p
