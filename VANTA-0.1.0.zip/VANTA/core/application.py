import tkinter as tk
import traceback
import sys
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path

from core.config import Config, VERSION, APP_NAME, LOG_DIR, state, save_state
from core.workspace import Workspace
from ui.theme import configure, VANTA
from ui.menus import menu
from ui.dialogs import about, askline
from ui.command_palette import Palette
from editor.editor import Editor
from explorer.explorer import Explorer
from terminal.terminal import Terminal
from runner.runner import Runner
from language.python import PythonAnalyzer
from tools_packages import PackageManager

class VantaApplication:
    def __init__(self):
        self.ed = None
        self.fullscreen = False
        self.cfg = Config()
        self.ws = Workspace()
        self.root = tk.Tk()
        self.root.title(f'{APP_NAME} {VERSION}')
        try: self.root.wm_class('VANTAIDE')
        except Exception: pass
        self.root.geometry('1360x840')
        self.root.minsize(980, 620)
        self.root.configure(bg=VANTA['bg'])
        configure(self.root)
        self._set_icon()
        self.runner = Runner(self.runner_event)
        self.an = PythonAnalyzer()
        self.build()
        self.root.config(menu=menu(self))
        self.keys()
        self.restore()
        self.root.report_callback_exception = self.exception
        self.root.protocol('WM_DELETE_WINDOW', self.closeapp)

    def _set_icon(self):
        try:
            icon = tk.PhotoImage(file=str(Path(__file__).resolve().parent.parent / 'assets' / 'vanta-logo.png'))
            self.root.iconphoto(True, icon)
            self._icon = icon
        except Exception:
            pass

    def build(self):
        top = tk.Frame(self.root, bg=VANTA['panel'], height=58, highlightthickness=1,
                       highlightbackground=VANTA['border'])
        top.pack(fill='x')
        top.pack_propagate(False)

        logo = tk.PhotoImage(file=str(Path(__file__).resolve().parent.parent / 'assets' / 'vanta-logo.png'))
        self._top_logo = logo
        tk.Label(top, image=logo, bg=VANTA['panel']).pack(side='left', padx=(14, 8))
        brand = tk.Frame(top, bg=VANTA['panel'])
        brand.pack(side='left', fill='y')
        tk.Label(brand, text='VANTA', bg=VANTA['panel'], fg='#FFFFFF',
                 font=('Segoe UI Semibold', 14)).pack(anchor='w', pady=(9, 0))
        tk.Label(brand, text='DEVELOPMENT ENVIRONMENT', bg=VANTA['panel'], fg=VANTA['muted'],
                 font=('Segoe UI', 7, 'bold')).pack(anchor='w')

        def tool(text, command, accent=False):
            b = tk.Button(top, text=text, command=command, relief='flat', bd=0,
                          bg=VANTA['accent'] if accent else VANTA['panel2'],
                          fg='#FFFFFF', activebackground='#9B73F8' if accent else VANTA['panel3'],
                          activeforeground='#FFFFFF', font=('Segoe UI Semibold', 9),
                          padx=14, pady=7, cursor='hand2')
            b.pack(side='right', padx=(5, 10 if accent else 3), pady=10)
            return b

        self.run_button = tool('RUN', self.run, True)
        self.stop_button = tool('STOP', self.stop)
        tool('COMMAND PALETTE', self.palette)

        # Main workspace: output on the left, editor in the centre and explorer below.
        workspace = tk.Frame(self.root, bg=VANTA['bg'])
        workspace.pack(fill='both', expand=True, padx=8, pady=8)

        left = tk.Frame(workspace, bg=VANTA['panel'], highlightthickness=1,
                        highlightbackground=VANTA['border'], width=300)
        left.pack(side='left', fill='y', padx=(0, 8))
        left.pack_propagate(False)
        tk.Label(left, text='OUTPUT', bg=VANTA['panel'], fg=VANTA['text'],
                 font=('Segoe UI Semibold', 9), anchor='w').pack(fill='x', padx=12, pady=(10, 7))
        self.out = tk.Text(left, bg='#090B10', fg='#DCE3ED',
                           insertbackground='white', font=('Cascadia Mono', 10), relief='flat',
                           highlightthickness=1, highlightbackground=VANTA['border'],
                           padx=10, pady=10, wrap='none')
        self.out.pack(fill='both', expand=True, padx=7, pady=(0, 7))

        right = tk.Frame(workspace, bg=VANTA['bg'])
        right.pack(side='left', fill='both', expand=True)

        editor_box = tk.Frame(right, bg=VANTA['panel'], highlightthickness=1,
                              highlightbackground=VANTA['border'])
        editor_box.pack(fill='both', expand=True)
        self.ed = Editor(editor_box, self.cfg, self.changed)
        self.ed.pack(fill='both', expand=True)

        explorer_box = tk.Frame(right, bg=VANTA['panel'], height=185,
                                highlightthickness=1, highlightbackground=VANTA['border'])
        explorer_box.pack(fill='x', pady=(8, 0))
        explorer_box.pack_propagate(False)
        tk.Label(explorer_box, text='EXPLORER', bg=VANTA['panel'], fg=VANTA['text'],
                 font=('Segoe UI Semibold', 9), anchor='w').pack(fill='x', padx=12, pady=(8, 3))
        self.ex = Explorer(explorer_box, self.openpath, lambda: self.ws.root)
        self.ex.pack(fill='both', expand=True, padx=5, pady=(0, 5))

        self.term = Terminal(self.root, lambda: self.ws.root or Path.cwd())
        self.term.pack_forget()

        status = tk.Frame(self.root, bg=VANTA['panel'], height=28,
                          highlightthickness=1, highlightbackground=VANTA['border'])
        status.pack(fill='x', padx=8)
        self.status = tk.Label(status, text='Ready', bg=VANTA['panel'], fg=VANTA['muted'], anchor='w',
                               font=('Segoe UI', 8))
        self.status.pack(side='left', padx=8, pady=5)
        self.prob = tk.Label(status, text='0 problems', bg=VANTA['panel'], fg=VANTA['muted'], anchor='e',
                             font=('Segoe UI', 8))
        self.prob.pack(side='right', padx=8, pady=5)

    def keys(self):
        bindings = {
            '<Control-n>': self.new, '<Control-o>': self.openfile, '<Control-s>': self.save,
            '<Control-Shift-s>': self.saveas, '<Control-w>': self.close, '<Control-f>': self.find,
            '<Control-h>': self.replace, '<Control-g>': self.goto, '<Control-Shift-p>': self.palette,
            '<F6>': self.run, '<F11>': self.toggle_fullscreen, '<Escape>': self.exit_fullscreen,
        }
        for key, func in bindings.items():
            self.root.bind_all(key, lambda e, f=func: (f(), 'break')[1])

    def restore(self):
        if len(sys.argv) > 1:
            try:
                candidate = Path(sys.argv[1].strip('\"'))
                if candidate.is_file():
                    self.openpath(candidate)
                    return
            except Exception:
                pass
        s = state()
        p = s.get('workspace')
        if self.cfg.get('restore_workspace') and p and Path(p).is_dir():
            self.ws.set_root(p)
            self.ex.refresh()

    def openpath(self, p):
        self.ed.open(p)
        self.changed()

    def openfile(self):
        p = filedialog.askopenfilename(parent=self.root)
        if p:
            self.openpath(Path(p))

    def openfolder(self):
        p = filedialog.askdirectory(parent=self.root)
        if p:
            self.ws.set_root(p)
            self.ex.refresh()
            self.root.title(f'{APP_NAME} - {Path(p).name}')

    def new(self): self.ed.new()
    def save(self): return self.ed.save()
    def saveas(self): return self.ed.save(True)

    def saveall(self):
        current = self.ed.cur
        for i in range(len(self.ed.docs)):
            self.ed.select(i)
            self.ed.save()
        if current is not None and self.ed.docs:
            self.ed.select(min(current, len(self.ed.docs) - 1))

    def close(self): return self.ed.close()

    def changed(self):
        if self.ed is None or self.ed.cur is None:
            return
        d = self.ed.docs[self.ed.cur]
        index = self.ed.t.index('insert').split('.')
        self.status.config(text=f'Ln {index[0]}  Col {int(index[1]) + 1}   {len(self.ed.t.get("1.0", "end-1c"))} chars')
        if d['path'] and d['path'].suffix.lower() == '.py':
            ds = self.an.diagnostics(self.ed.t.get('1.0', 'end-1c'))
            self.prob.config(text=f'{len(ds)} problems')
            self.ed.t.tag_remove('diag', '1.0', 'end')
            for x in ds:
                self.ed.t.tag_add('diag', f'{x.line}.{x.column}', f'{x.line}.end')

    def find(self):
        q = simpledialog.askstring('Find', 'Find:', parent=self.root)
        if not q: return
        self.ed.t.tag_remove('match', '1.0', 'end')
        p = '1.0'
        while True:
            p = self.ed.t.search(q, p, stopindex='end', nocase=True)
            if not p: break
            e = f'{p}+{len(q)}c'
            self.ed.t.tag_add('match', p, e)
            p = e

    def replace(self):
        a = simpledialog.askstring('Replace', 'Find:', parent=self.root)
        if a is None: return
        b = simpledialog.askstring('Replace', 'Replace with:', parent=self.root)
        if b is None: return
        x = self.ed.t.get('1.0', 'end-1c').replace(a, b)
        self.ed.t.delete('1.0', 'end'); self.ed.t.insert('1.0', x)

    def goto(self):
        n = askline(self.root)
        if n:
            self.ed.t.mark_set('insert', f'{n}.0')
            self.ed.t.see('insert')
            self.changed()

    def toggle_explorer(self):
        try:
            if str(self.ex) in self.main.panes():
                self.main.forget(self.ex)
            else:
                self.main.insert(0, self.ex, weight=1)
        except Exception:
            pass

    def toggle_terminal(self):
        if self.term.winfo_ismapped():
            self.term.pack_forget(); self.out.pack(fill='x', padx=8)
        else:
            self.out.pack_forget(); self.term.pack(fill='both', expand=False, padx=8, pady=4, after=self.main)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes('-fullscreen', self.fullscreen)

    def exit_fullscreen(self):
        if self.fullscreen:
            self.fullscreen = False
            self.root.attributes('-fullscreen', False)

    def run(self):
        if self.ed.cur is None:
            return
        d = self.ed.docs[self.ed.cur]
        code = self.ed.t.get('1.0', 'end-1c')
        if d['path'] and d['path'].suffix.lower() != '.py':
            messagebox.showinfo('VANTA', 'The built-in runner currently targets Python files.', parent=self.root)
            return

        # Unsaved documents run directly from memory. Nothing has to be saved first.
        if not d['path']:
            display_name = d.get('name') or 'Untitled.py'
            d['name'] = display_name
            self.out.delete('1.0', 'end')
            self.out.insert('end', f'▶ Running {display_name}  ·  unsaved\n\n')
            self.runner.run(display_name, self.ws.root or Path.cwd(), code)
            return

        d['text'] = code
        if d['dirty'] and not self.ed.save():
            return
        self.out.delete('1.0', 'end')
        self.out.insert('end', f'▶ Running {d["path"].name}...\n\n')
        self.runner.run(d['path'], self.ws.root or d['path'].parent)

    def run_selection(self):
        try: c = self.ed.t.get('sel.first', 'sel.last')
        except tk.TclError: return
        self.out.delete('1.0', 'end')
        self.runner.run('<selection>', self.ws.root or Path.cwd(), c)

    def stop(self): self.runner.stop()

    def runner_event(self, k, x):
        def update():
            if k == 'out': self.out.insert('end', x)
            elif k == 'exit': self.out.insert('end', f'\n[exit {x}]\n')
            else: self.out.insert('end', f'\n[error] {x}\n')
            self.out.see('end')
        self.root.after(0, update)

    def packages(self):
        PackageManager(self.root, self.ws.root or Path.cwd())

    def palette(self):
        cmds = [
            ('Open File', self.openfile), ('Open Folder', self.openfolder), ('New File', self.new),
            ('Save', self.save), ('Save All', self.saveall), ('Close Tab', self.close),
            ('Find', self.find), ('Replace', self.replace), ('Go to Line', self.goto),
            ('Toggle Explorer', self.toggle_explorer), ('Toggle Terminal', self.toggle_terminal),
            ('Fullscreen', self.toggle_fullscreen), ('Run Current File', self.run),
            ('Run Selection', self.run_selection), ('Stop', self.stop),
            ('Python Packages / Extensions', self.packages), ('Font +', lambda: self.ed.fontchange(1)),
            ('Font -', lambda: self.ed.fontchange(-1)), ('Word Wrap', self.ed.wrap), ('About VANTA', self.about)
        ]
        Palette(self.root, cmds)

    def about(self): about(self.root)

    def closeapp(self):
        if not self.ed.close():
            return
        try: self.runner.stop()
        except Exception: pass
        try: self.term.destroy()
        except Exception: pass
        try: save_state({'workspace': str(self.ws.root) if self.ws.root else ''})
        except Exception: pass
        try: self.cfg.save()
        except Exception: pass
        self.root.quit()
        self.root.destroy()

    def exception(self, exc, val, tb):
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        (LOG_DIR / 'vanta.log').open('a', encoding='utf8').write(traceback.format_exc() + '\n')
        messagebox.showerror('VANTA Error', str(val), parent=self.root)

    def start(self):
        self.root.mainloop()
