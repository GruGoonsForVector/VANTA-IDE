import subprocess,sys,threading
class Runner:
 def __init__(self,cb):self.p=None;self.cb=cb
 def run(self,path,cwd,code=None):
  def w():
   try:
    cmd=[sys.executable,'-u',str(path)] if code is None else [sys.executable,'-u','-c',code]; self.p=subprocess.Popen(cmd,cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    for x in self.p.stdout:self.cb('out',x)
    self.cb('exit',self.p.wait())
   except Exception as e:self.cb('err',str(e))
  threading.Thread(target=w,daemon=True).start()
 def stop(self):
  if self.p and self.p.poll() is None:
   try:self.p.terminate()
   except Exception:pass
