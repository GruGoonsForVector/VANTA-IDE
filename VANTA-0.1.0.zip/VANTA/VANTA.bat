@echo off
setlocal
cd /d "%~dp0"
if exist "%LocalAppData%\Programs\Python\Python313\pythonw.exe" start "" "%LocalAppData%\Programs\Python\Python313\pythonw.exe" "%~dp0vanta.py" %* & exit /b
where pythonw.exe >nul 2>nul && start "" pythonw.exe "%~dp0vanta.py" %* && exit /b
where py.exe >nul 2>nul && py.exe -3 "%~dp0vanta.py" %* && exit /b
where python.exe >nul 2>nul && start "" python.exe "%~dp0vanta.py" %* && exit /b
echo VANTA could not find Python.
echo Install Python 3 from python.org and make sure Python is on PATH.
pause
