# Changelog

## 0.1.0-dev
Initial VANTA IDE foundation.
