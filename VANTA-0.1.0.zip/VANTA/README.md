# VANTA IDE 0.1.0-dev

VANTA is a modular dark desktop IDE built with Python and the standard library. It requires no pip packages, Node, Rust or Electron.

## Run
`python vanta.py`

## Features
- real filesystem explorer and workspace support
- multi-document editor with line numbers, syntax highlighting, undo/redo, tabs, save/open, find/replace and indentation
- Python AST diagnostics and symbol analysis foundation
- background Python runner with stdout/stderr capture and stop
- real Windows shell terminal through subprocess
- command palette
- persistent settings and workspace state
- modular architecture prepared for LSP/DAP and extensions

## Limitations
Full LSP, DAP debugging, advanced Git staging and true Windows PTY behavior are not yet implemented. The terminal backend intentionally uses subprocess so it remains standard-library-only.

## Shortcuts
Ctrl+N new, Ctrl+O open, Ctrl+S save, Ctrl+Shift+S save as, Ctrl+W close, Ctrl+F find, Ctrl+H replace, Ctrl+G go to line, Ctrl+Shift+P command palette.

## Launching VANTA on Windows

Double-click `VANTA.bat`. It launches VANTA with `pythonw.exe` when available so no console window is needed. You can also drag a file onto the batch launcher or pass a path from a shortcut.

## Python packages

Use **Tools > Python Packages / Extensions** to install or remove Python packages. VANTA can run `python -m pip` for pip installation, upgrades, package listing and packages such as Pillow, NumPy and Manim.
