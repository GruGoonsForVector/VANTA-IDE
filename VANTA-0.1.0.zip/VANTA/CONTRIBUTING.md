# Contributing

Run `python -m unittest discover -s tests -v`. Keep subsystems modular and standard-library-first.
