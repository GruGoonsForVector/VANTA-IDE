import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, messagebox

class PackageManager(tk.Toplevel):
    QUICK = ['pip', 'pillow', 'numpy', 'matplotlib', 'manim']

    def __init__(self, master, cwd):
        super().__init__(master)
        self.title('VANTA Package Manager')
        self.geometry('760x540')
        self.minsize(620, 420)
        self.configure(bg='#0B0D12')
        self.cwd = cwd
        self.proc = None
        self.protocol('WM_DELETE_WINDOW', self.close)

        head = ttk.Frame(self)
        head.pack(fill='x', padx=16, pady=(16, 8))
        ttk.Label(head, text='Python Packages', style='Title.TLabel').pack(side='left')
        ttk.Label(head, text='Install and manage packages for VANTA', style='Muted.TLabel').pack(side='left', padx=12)

        row = ttk.Frame(self)
        row.pack(fill='x', padx=16, pady=8)
        self.package = ttk.Entry(row)
        self.package.pack(side='left', fill='x', expand=True)
        self.package.insert(0, 'pillow')
        ttk.Button(row, text='Install', style='Accent.TButton', command=self.install).pack(side='left', padx=6)
        ttk.Button(row, text='Uninstall', command=self.uninstall).pack(side='left')

        quick = ttk.Frame(self)
        quick.pack(fill='x', padx=16, pady=4)
        ttk.Label(quick, text='Quick install:', style='Muted.TLabel').pack(side='left', padx=(0, 8))
        for name in self.QUICK:
            ttk.Button(quick, text=name, command=lambda n=name: self.quick(n)).pack(side='left', padx=2)

        actions = ttk.Frame(self)
        actions.pack(fill='x', padx=16, pady=8)
        ttk.Button(actions, text='Upgrade pip', command=self.upgrade_pip).pack(side='left')
        ttk.Button(actions, text='List installed', command=self.list_packages).pack(side='left', padx=6)
        ttk.Button(actions, text='Install requirements.txt', command=self.install_requirements).pack(side='left')

        self.output = tk.Text(self, bg='#07090D', fg='#DCE3ED', insertbackground='white',
                              font=('Consolas', 9), relief='flat', wrap='word')
        self.output.pack(fill='both', expand=True, padx=16, pady=(4, 16))
        self.write('VANTA Package Manager\nPython: ' + sys.executable + '\n\n')

    def write(self, text):
        self.output.insert('end', text)
        self.output.see('end')

    def run_cmd(self, args):
        if self.proc and self.proc.poll() is None:
            messagebox.showinfo('VANTA', 'A package operation is already running.', parent=self)
            return
        self.write('$ ' + ' '.join(args) + '\n')
        def worker():
            try:
                self.proc = subprocess.Popen(args, cwd=str(self.cwd), stdout=subprocess.PIPE,
                                             stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace')
                for line in self.proc.stdout:
                    self.after(0, self.write, line)
                code = self.proc.wait()
                self.after(0, self.write, f'\n[exit {code}]\n\n')
            except Exception as e:
                self.after(0, self.write, f'\nERROR: {e}\n\n')
            finally:
                self.proc = None
        threading.Thread(target=worker, daemon=True).start()

    def normalized(self):
        return self.package.get().strip()

    def install(self):
        p = self.normalized()
        if not p:
            return
        self.run_cmd([sys.executable, '-m', 'pip', 'install', p])

    def uninstall(self):
        p = self.normalized()
        if p:
            self.run_cmd([sys.executable, '-m', 'pip', 'uninstall', '-y', p])

    def quick(self, name):
        self.package.delete(0, 'end')
        self.package.insert(0, name)
        self.install()

    def upgrade_pip(self):
        self.run_cmd([sys.executable, '-m', 'pip', 'install', '--upgrade', 'pip'])

    def list_packages(self):
        self.run_cmd([sys.executable, '-m', 'pip', 'list'])

    def install_requirements(self):
        self.run_cmd([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])

    def close(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
            except Exception:
                pass
        self.destroy()
