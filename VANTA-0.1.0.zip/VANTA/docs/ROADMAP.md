# Roadmap

0.1 foundation

0.2 richer Python analysis, search indexing and Git UI

0.3 LSP/DAP foundations

0.4 extensions and project tasks

1.0 production packaging and stable APIs
