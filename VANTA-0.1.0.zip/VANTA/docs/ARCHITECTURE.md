# Architecture

core handles lifecycle/configuration/workspaces. editor handles documents and editing. explorer handles filesystem UI. terminal and runner isolate process execution. language isolates language intelligence. ui contains shared presentation. Future LSP/DAP adapters should remain outside editor widgets.
