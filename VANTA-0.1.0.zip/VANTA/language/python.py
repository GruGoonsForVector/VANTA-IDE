import ast,builtins,keyword,tokenize,io
from dataclasses import dataclass
@dataclass
class Diagnostic: line:int; column:int; message:str; severity:str='error'
class PythonAnalyzer:
 def diagnostics(self,s):
  try:ast.parse(s);return []
  except SyntaxError as e:return [Diagnostic(e.lineno or 1,(e.offset or 1)-1,e.msg)]
 def symbols(self,s):
  try:t=ast.parse(s)
  except SyntaxError:return []
  out=[]
  for n in ast.walk(t):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):out.append(n.name)
   elif isinstance(n,ast.Assign):
    for x in n.targets:
     if isinstance(x,ast.Name):out.append(x.id)
  return sorted(set(out))
 def completions(self,s,p):
  words=set(keyword.kwlist)|set(dir(builtins))|set(self.symbols(s))
  try: words|={t.string for t in tokenize.generate_tokens(io.StringIO(s).readline) if t.type==tokenize.NAME}
  except Exception:pass
  return sorted(x for x in words if x.startswith(p) and x!=p)
