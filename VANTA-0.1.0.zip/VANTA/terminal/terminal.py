import tkinter as tk,subprocess,threading,os
from tkinter import ttk
class Terminal(ttk.Frame):
 def __init__(self,m,cwd):
  super().__init__(m); self.cwd=cwd; self.out=tk.Text(self,bg='#050505',fg='#ddd',insertbackground='white',font=('Consolas',10),relief='flat'); self.out.pack(fill='both',expand=True); self.e=tk.Entry(self,bg='#101010',fg='white',insertbackground='white',relief='flat'); self.e.pack(fill='x',padx=8,pady=6); self.e.bind('<Return>',self.run); self.hist=[]; self.i=0; self.write('VANTA terminal\n')
 def write(self,s):self.out.insert('end',s);self.out.see('end')
 def run(self,e=None):
  c=self.e.get().strip(); self.e.delete(0,'end')
  if not c:return 'break'
  self.hist.append(c);self.write('> '+c+'\n'); threading.Thread(target=self.work,args=(c,),daemon=True).start(); return 'break'
 def work(self,c):
  try:
   p=subprocess.Popen(c,shell=True,cwd=str(self.cwd() or os.getcwd()),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace'); o,_=p.communicate(); self.after(0,self.write,o+'\n[exit %s]\n'%p.returncode)
  except Exception as x:self.after(0,self.write,str(x)+'\n')
 def clear(self):self.out.delete('1.0','end')
