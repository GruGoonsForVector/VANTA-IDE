import unittest,tempfile
from pathlib import Path
from core.workspace import Workspace
from language.python import PythonAnalyzer
from editor.search import find_matches
class T(unittest.TestCase):
 def test_workspace(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'.git').mkdir();self.assertEqual(Workspace.detect_root(p/'x'),p)
 def test_python(self):
  a=PythonAnalyzer();self.assertTrue(a.diagnostics('print('));self.assertIn('score',a.symbols('def score():\n pass'))
 def test_search(self):self.assertEqual(len(find_matches('cat concatenate','cat',whole=True)),1)
if __name__=='__main__':unittest.main()
